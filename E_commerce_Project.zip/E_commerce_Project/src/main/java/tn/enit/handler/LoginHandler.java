package tn.enit.handler;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.client.api.worker.JobHandler;

public class LoginHandler implements JobHandler {

    @Override
    public void handle(JobClient client, ActivatedJob job) throws Exception {
        String username = (String) job.getVariablesAsMap().get("email");
        String password = (String) job.getVariablesAsMap().get("password");

        if (authenticate(username, password)) {
            client.newCompleteCommand(job.getKey()).send().join();
        } else {
            client.newFailCommand(job.getKey()).retries(0).errorMessage("Invalid login credentials").send().join();
        }
    }

    private boolean authenticate(String username, String password) {
        // Simulate authentication logic
        return "admin".equals(username) && "admin123".equals(password);
    }
}
