package tn.enit.handler;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.client.api.worker.JobHandler;

public class AddToCartHandler implements JobHandler {

    @Override
    public void handle(JobClient client, ActivatedJob job) throws Exception {
        String productId = (String) job.getVariablesAsMap().get("productId");
        int quantity = Integer.parseInt((String) job.getVariablesAsMap().get("quantity"));

        // Logique pour ajouter le produit au panier
        // Ceci est une simulation
        System.out.println("Added " + quantity + " of product " + productId + " to cart");

        client.newCompleteCommand(job.getKey()).send().join();
    }
}
