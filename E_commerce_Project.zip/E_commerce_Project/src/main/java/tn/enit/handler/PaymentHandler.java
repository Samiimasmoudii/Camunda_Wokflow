package tn.enit.handler;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.client.api.worker.JobHandler;

public class PaymentHandler implements JobHandler {

    @Override
    public void handle(JobClient client, ActivatedJob job) throws Exception {
        String paymentDetails = (String) job.getVariablesAsMap().get("paymentDetails");

        // Simuler une vérification de paiement
        if (processPayment(paymentDetails)) {
            client.newCompleteCommand(job.getKey()).send().join();
        } else {
            client.newFailCommand(job.getKey()).retries(0).errorMessage("Payment failed").send().join();
        }
    }

    private boolean processPayment(String paymentDetails) {
        // Logique pour traiter le paiement
        return true; // Simuler un paiement réussi
    }
}
