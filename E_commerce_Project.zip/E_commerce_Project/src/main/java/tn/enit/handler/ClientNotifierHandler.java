package tn.enit.handler;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.client.api.worker.JobHandler;
import tn.enit.service.ClientNotifier;

public class ClientNotifierHandler implements JobHandler {

    ClientNotifier clientNotifierService = new ClientNotifier();

    @Override
    public void handle(JobClient client, ActivatedJob job) throws Exception {
        // Extrait les variables nécessaires du job
        String customerEmail = job.getVariablesAsMap().get("customerEmail").toString();
        String orderDetails = job.getVariablesAsMap().get("orderDetails").toString();

        // Envoie l'email de confirmation
        clientNotifierService.sendOrderConfirmationEmail(customerEmail, orderDetails);

        // Indique au moteur de workflow que le job a été complété avec succès
        client.newCompleteCommand(job.getKey()).send().join();
    }
}
