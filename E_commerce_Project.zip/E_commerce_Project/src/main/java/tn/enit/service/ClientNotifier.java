package tn.enit.service;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


public class ClientNotifier {

    public void sendOrderConfirmationEmail(String customerEmail, String orderDetails) {
        final String email = "email_client"; // Remplacez par votre adresse email
        final String password = "password_client"; // Remplacez par votre mot de passe

        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.example.com"); // Remplacez par votre serveur SMTP
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); // Activez TLS

        Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(email, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("maramzribi8@gmail.com")); // Votre email
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(customerEmail) // Email du destinataire
            );
            message.setSubject("Confirmation de votre commande");
            message.setText("Cher client,\n\nMerci pour votre commande. Voici les détails de votre commande:\n" + orderDetails);

            Transport.send(message);

            System.out.println("Email de confirmation envoyé avec succès!");

        } catch (MessagingException e) {
            e.printStackTrace();
            System.out.println("Erreur lors de l'envoi de l'email");
        }
    }
}
