package tn.enit.service;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.worker.JobWorker;
import tn.enit.handler.LoginHandler;

public class AuthService {

    private final ZeebeClient zeebeClient;
    private JobWorker loginWorker;

    public AuthService(String zeebeBroker) {
        // Initialiser le client Zeebe
        this.zeebeClient = ZeebeClient.newClientBuilder()
                .overrideAuthority(zeebeBroker)
                .usePlaintext()
                .build();
    }

    public void start() {
        // Démarrer le worker pour le traitement des authentifications
        loginWorker = zeebeClient.newWorker()
                .jobType("login-service")
                .handler(new LoginHandler())
                .fetchVariables("email", "password")
                .open();
    }

    public void stop() {
        // Fermer le worker et le client Zeebe
        if (loginWorker != null) {
            loginWorker.close();
        }
        zeebeClient.close();
    }

    public static void main(String[] args) {
        // Exemple de point d'entrée pour démarrer le service
        AuthService service = new AuthService("127.0.0.1:26500");
        service.start();

        // Ajouter un hook d'arrêt pour assurer une fermeture propre
        Runtime.getRuntime().addShutdownHook(new Thread(service::stop));
    }
}
