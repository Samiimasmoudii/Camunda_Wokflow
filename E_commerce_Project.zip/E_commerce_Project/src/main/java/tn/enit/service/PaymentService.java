package tn.enit.service;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.worker.JobWorker;
import tn.enit.handler.PaymentHandler;

public class PaymentService {

    private final ZeebeClient zeebeClient;
    private JobWorker paymentWorker;

    public PaymentService(String zeebeBroker) {
        // Initialiser le client Zeebe
        this.zeebeClient = ZeebeClient.newClientBuilder()
                .overrideAuthority(zeebeBroker)
                .usePlaintext()
                .build();
    }

    public void start() {
        // Démarrer le worker pour le traitement des paiements
        paymentWorker = zeebeClient.newWorker()
                .jobType("payment-service")
                .handler(new PaymentHandler())
                .fetchVariables("paymentDetails")
                .open();
    }

    public void stop() {
        // Fermer le worker et le client Zeebe
        if (paymentWorker != null) {
            paymentWorker.close();
        }
        zeebeClient.close();
    }

    public static void main(String[] args) {
        // Exemple de point d'entrée pour démarrer le service
        PaymentService service = new PaymentService("127.0.0.1:26500");
        service.start();

        // Ajouter un hook d'arrêt pour assurer une fermeture propre
        Runtime.getRuntime().addShutdownHook(new Thread(service::stop));
    }
}
