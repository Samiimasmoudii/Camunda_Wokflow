package tn.enit.service;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.worker.JobWorker;
import tn.enit.handler.AddToCartHandler;

public class CartService {

    private final ZeebeClient zeebeClient;
    private JobWorker addToCartWorker;

    public CartService(String zeebeBroker) {
        // Initialiser le client Zeebe
        this.zeebeClient = ZeebeClient.newClientBuilder()
                .overrideAuthority(zeebeBroker)
                .usePlaintext()
                .build();
    }

    public void start() {
        // Démarrer le worker pour le traitement de l'ajout au panier
        addToCartWorker = zeebeClient.newWorker()
                .jobType("add-to-cart-service")
                .handler(new AddToCartHandler())
                .fetchVariables("productId", "quantity")
                .open();
    }

    public void stop() {
        // Fermer le worker et le client Zeebe
        if (addToCartWorker != null) {
            addToCartWorker.close();
        }
        zeebeClient.close();
    }

    public static void main(String[] args) {
        // Exemple de point d'entrée pour démarrer le service
        CartService service = new CartService("127.0.0.1:26500");
        service.start();

        // Ajouter un hook d'arrêt pour assurer une fermeture propre
        Runtime.getRuntime().addShutdownHook(new Thread(service::stop));
    }
}
