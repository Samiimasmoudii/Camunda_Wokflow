package tn.enit;

import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.worker.JobWorker;
import io.camunda.zeebe.client.impl.oauth.OAuthCredentialsProvider;
import io.camunda.zeebe.client.impl.oauth.OAuthCredentialsProviderBuilder;
import tn.enit.handler.ClientNotifierHandler;

import java.time.Duration;

public class Main {

    // Constants for Zeebe connection configuration
    private static final String ZEEBE_ADDRESS = "53c06607-7d5b-4253-b34c-06249350375a.bru-2.zeebe.camunda.io:443";
    private static final String ZEEBE_CLIENT_ID = "~qm5J-oc5D7ICRaysBtHZZydGQLUwsfA";
    private static final String ZEEBE_CLIENT_SECRET = "QUM6XbDgTiLzdY_amiIT6JnxPf.7Fr.7E7QLkhVvXfnafL47~KFGdd7KKbificI_";
    private static final String ZEEBE_AUTHORIZATION_SERVER_URL = "https://login.cloud.camunda.io/oauth/token";
    private static final String ZEEBE_TOKEN_AUDIENCE = "zeebe.camunda.io";

    // Define the job type
    private static final String ENVOI_ERP_JOB_TYPE = "Activity_0xz60rz"; // Define your job type

    // Define worker timeout and time to live
    private static final long WORKER_TIMEOUT = 30; // Example timeout in seconds
    private static final long WORKER_TIME_TO_LIVE = 60000; // Example time to live in milliseconds

    public static void main(String[] args) {
        // Create OAuth credentials provider for authentication
        final OAuthCredentialsProvider credentialsProvider =
                new OAuthCredentialsProviderBuilder()
                        .authorizationServerUrl(ZEEBE_AUTHORIZATION_SERVER_URL)
                        .audience(ZEEBE_TOKEN_AUDIENCE)
                        .clientId(ZEEBE_CLIENT_ID)
                        .clientSecret(ZEEBE_CLIENT_SECRET)
                        .build();

        // Initialize Zeebe client and connect to the server
        try (final ZeebeClient client =
                     ZeebeClient.newClientBuilder()
                             .gatewayAddress(ZEEBE_ADDRESS)
                             .credentialsProvider(credentialsProvider)
                             .build()) {
            // Print topology to confirm successful connection
            System.out.println("Connected to: " + client.newTopologyRequest().send().join());



        } catch (Exception e) {
            // Handle exceptions
            e.printStackTrace();
            System.out.println("Failed to connect to Zeebe.");
        }
    }
}
